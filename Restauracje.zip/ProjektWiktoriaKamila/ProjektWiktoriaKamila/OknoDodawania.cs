﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ProjektWiktoriaKamila
{
    public partial class OknoDodawania : Form
    {
        public OknoDodawania()
        {
            InitializeComponent();
        }

        private void btnZamknij_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnWroc_Click(object sender, EventArgs e)
        {
            this.Close();
            Form form = new Form1();
            form.ShowDialog();
        }
        public void UstawPuste()
        {
            txtNazwa.Text = "";
            txtMiasto.Text = "";
            txtUlica.Text = "";
            cmbWojewodztwo.Text = "";
            mtxtGOtwarcie.Text = "";
            mtxtGZamkniecie.Text = "";
            cmbDowoz.Text = "";
            cmbTypRestauracji.Text = "";
            mtxtNrTelefonu.Text = "";
        }

        public int iloscRecordow()
        {
            BazaDanych.polaczenie.Open();
            var cmd = BazaDanych.polaczenie.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT MAX(id) FROM [Restauracje]";
            var countResult = cmd.ExecuteScalar();
            int count = countResult is System.DBNull ? 0 : (int)(long)countResult;
            cmd.ExecuteNonQuery();
            BazaDanych.polaczenie.Close();
            return count + 1;
        }
        private void btnDodajRestauracje_Click(object sender, EventArgs e)
        {
            string nazwa = txtNazwa.Text;
            string miasto = txtMiasto.Text;
            string ulica = txtUlica.Text;
            string wojewodztwo = cmbWojewodztwo.Text;
            string gOtwarcia = mtxtGOtwarcie.Text;
            string gZamkniecia = mtxtGZamkniecie.Text;
            string dowoz = cmbDowoz.Text;
            string typRestauracji = cmbTypRestauracji.Text;
            string nrTelefonu = mtxtNrTelefonu.Text;
            int id = iloscRecordow();

            BazaDanych.polaczenie.Open();
            var cmd = BazaDanych.polaczenie.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = $"INSERT INTO [Restauracje] (Id,Nazwa,Miasto,Ulica,NrTelefonu,Wojewodztwo,GOtwarcia,GZamkniecia,Dowoz,TypRestauracji) VALUES" +
                $" ({id}, '{nazwa}', '{miasto}', '{ulica}', '{nrTelefonu}', '{wojewodztwo}', '{gOtwarcia}', '{gZamkniecia}', '{dowoz}', '{typRestauracji}')";
            cmd.ExecuteNonQuery();
            BazaDanych.polaczenie.Close();

            UstawPuste();
            MessageBox.Show("Restauracja zostala dodana i ma id=" + id);

        }

        private void mtxtGOtwarcie_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }
    }
}
