﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjektWiktoriaKamila
{
    public partial class OknoModyfikacji : Form
    {
        public OknoModyfikacji()
        {
            InitializeComponent();
        }

        private void btnWroc_Click(object sender, EventArgs e)
        {
            
            Form from = new Form1();
            from.ShowDialog();

        }

        private void btnZamknij_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        public void UstawPuste()
        {
            txtNazwa.Text = "";
            txtMiasto.Text = "";
            txtUlica.Text = "";
            cmbWojewodztwo.Text = "";
            mtxtGOtwarcie.Text = "";
            mtxtGZamkniecie.Text = "";
            cmbDowoz.Text = "";
            cmbTypRestauracji.Text = "";
            mtxtNrTelefonu.Text = "";

        }
        public int DaneID(int id)
        {
            BazaDanych.polaczenie.Open();
            var cmd = BazaDanych.polaczenie.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT COUNT(*) FROM [Restauracje]  WHERE Id =" + id;
            int wynik = (int)(long)cmd.ExecuteScalar();
            cmd.ExecuteNonQuery();
            BazaDanych.polaczenie.Close();
            return wynik;
        }
        public void WyswietlDane()
        {
            BazaDanych.polaczenie.Open();
            var cmd = BazaDanych.polaczenie.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM [Restauracje]  " ;
            
            SQLiteDataAdapter adapter = new SQLiteDataAdapter(cmd);
            DataTable tabela = new DataTable();
            adapter.Fill(tabela);

            dataGridView1.DataSource = tabela;
            BazaDanych.polaczenie.Close();
        }
        public void UzupelnijDane(int id)
        {
            lDowoz.Text =  WyswietDaneRestauracji(id, "Dowoz");
            lGOtwarcia.Text = WyswietDaneRestauracji(id, "GOtwarcia");
            lGZamkniecia.Text = WyswietDaneRestauracji(id, "GZamkniecia");
            lNazwa.Text = WyswietDaneRestauracji(id, "Nazwa");
            IMiasto.Text = WyswietDaneRestauracji(id, "Miasto");
            lWojewodztwo.Text = WyswietDaneRestauracji(id, "Wojewodztwo");
            lNrTelefonu.Text = WyswietDaneRestauracji(id, "NrTelefonu");
            lUlica.Text = WyswietDaneRestauracji(id, "Ulica");
            lTypRestauracji.Text = WyswietDaneRestauracji(id, "TypRestauracji");

        }
        public string WyswietDaneRestauracji(int id,string JakieDane)
        {
            BazaDanych.polaczenie.Open();
            var cmd = BazaDanych.polaczenie.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = $"SELECT {JakieDane} FROM [Restauracje]  WHERE Id =" + id;
            var reader = cmd.ExecuteReader();
            reader.Read();//odczytanie poszegolnych wierszy.
            string wynik  = reader.GetString(0);//pobranie wartosci z pierwszej kolumny
            reader.Close();
            BazaDanych.polaczenie.Close();
            return wynik;
            

        }

        public void Czysc()
        {
             txtNazwa.Text="";
             txtMiasto.Text="";
             txtUlica.Text="";
             cmbWojewodztwo.Text="";
             mtxtGOtwarcie.Text="";
             mtxtGZamkniecie.Text="";
             cmbDowoz.Text="";
             cmbTypRestauracji.Text="";
             mtxtNrTelefonu.Text="";

        }

        private void btnModyfikuj_Click(object sender, EventArgs e)
        {
            int IdDoZaktualizowania = (int)numberId.Value;
            if (DaneID(IdDoZaktualizowania) == 0)
            {
                MessageBox.Show("Nie istnieje w bazie danych resturacje o Id=" + IdDoZaktualizowania);
            }
            else
            {
                string nazwa = txtNazwa.Text;
                string miasto = txtMiasto.Text;
                string ulica = txtUlica.Text;
                string wojewodztwo = cmbWojewodztwo.Text;
                string gOtwarcia = mtxtGOtwarcie.Text;
                string gZamkniecia = mtxtGZamkniecie.Text;
                string dowoz = cmbDowoz.Text;
                string typRestauracji = cmbTypRestauracji.Text;
                string nrTelefonu = mtxtNrTelefonu.Text;


                BazaDanych.polaczenie.Open();
                var cmd = BazaDanych.polaczenie.CreateCommand();

                if (nazwa != "")
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "UPDATE [Restauracje] SET Nazwa = '" + nazwa + "' WHERE Id=" + IdDoZaktualizowania;
                    cmd.ExecuteNonQuery();
                }
                if (miasto != "")
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "UPDATE [Restauracje] SET Miasto = '" + miasto + "' WHERE Id=" + IdDoZaktualizowania;
                    cmd.ExecuteNonQuery();
                }
                if (ulica != "")
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "UPDATE [Restauracje] SET Ulica = '" + ulica + "' WHERE Id=" + IdDoZaktualizowania;
                    cmd.ExecuteNonQuery();
                }
                if (nrTelefonu != "   -   -")
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "UPDATE [Restauracje] SET NrTelefonu = '" + nrTelefonu + "' WHERE Id=" + IdDoZaktualizowania;
                    cmd.ExecuteNonQuery();
                }
                if (wojewodztwo != "")
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "UPDATE [Restauracje] SET Wojewodztwo = '" + wojewodztwo + "' WHERE Id=" + IdDoZaktualizowania;
                    cmd.ExecuteNonQuery();
                }
                if (gOtwarcia != "  :")
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "UPDATE [Restauracje] SET GOtwarcia = '" + gOtwarcia + "' WHERE Id=" + IdDoZaktualizowania;
                    cmd.ExecuteNonQuery();
                }
                if (gZamkniecia != "  :")
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "UPDATE [Restauracje] SET GZamkniecia = '" + gZamkniecia + "' WHERE Id=" + IdDoZaktualizowania;
                    cmd.ExecuteNonQuery();
                }
                if (dowoz != "")
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "UPDATE [Restauracje] SET Dowoz = '" + dowoz + "' WHERE Id=" + IdDoZaktualizowania;
                    cmd.ExecuteNonQuery();
                }
                if (typRestauracji != "")
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "UPDATE [Restauracje] SET TypRestauracji = '" + typRestauracji + "' WHERE Id=" + IdDoZaktualizowania;
                    cmd.ExecuteNonQuery();
                }

                BazaDanych.polaczenie.Close();

                UstawPuste();
                MessageBox.Show("Resturacje o Id=" + IdDoZaktualizowania + " zostala zaktualizowana", "Aktualizacja danych", MessageBoxButtons.OK);

            }
            WyswietlDane();
            UzupelnijDane(IdDoZaktualizowania);

        }

        private void btnWyswietRestauracje_Click(object sender, EventArgs e)
        {
            int IdDoZaktualizowania = (int)numberId.Value;
            if (DaneID(IdDoZaktualizowania) == 0)
            {
                MessageBox.Show("Nie istnieje w bazie danych resturacje o Id=" + IdDoZaktualizowania);
            }
            else
            {
                
                UzupelnijDane(IdDoZaktualizowania);
            }

        }

        private void btnWyswietlTabele_Click(object sender, EventArgs e)
        {
           
           
        }

        private void NaZaloadowanie(object sender, EventArgs e)
        {
            WyswietlDane();
        }
    }
}
