﻿
namespace ProjektWiktoriaKamila
{
    partial class OknoDodawania
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OknoDodawania));
            this.btnZamknij = new System.Windows.Forms.Button();
            this.btnDodajRestauracje = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtNazwa = new System.Windows.Forms.TextBox();
            this.txtMiasto = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.cmbWojewodztwo = new System.Windows.Forms.ComboBox();
            this.cmbTypRestauracji = new System.Windows.Forms.ComboBox();
            this.cmbDowoz = new System.Windows.Forms.ComboBox();
            this.mtxtGOtwarcie = new System.Windows.Forms.MaskedTextBox();
            this.mtxtGZamkniecie = new System.Windows.Forms.MaskedTextBox();
            this.mtxtNrTelefonu = new System.Windows.Forms.MaskedTextBox();
            this.txtUlica = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnZamknij
            // 
            this.btnZamknij.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnZamknij.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.75F);
            this.btnZamknij.Location = new System.Drawing.Point(339, 567);
            this.btnZamknij.Name = "btnZamknij";
            this.btnZamknij.Size = new System.Drawing.Size(271, 59);
            this.btnZamknij.TabIndex = 0;
            this.btnZamknij.Text = "Zamknij";
            this.btnZamknij.UseVisualStyleBackColor = false;
            this.btnZamknij.Click += new System.EventHandler(this.btnZamknij_Click);
            // 
            // btnDodajRestauracje
            // 
            this.btnDodajRestauracje.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnDodajRestauracje.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.btnDodajRestauracje.Location = new System.Drawing.Point(29, 567);
            this.btnDodajRestauracje.Name = "btnDodajRestauracje";
            this.btnDodajRestauracje.Size = new System.Drawing.Size(271, 59);
            this.btnDodajRestauracje.TabIndex = 2;
            this.btnDodajRestauracje.Text = "Dodaj restaurację";
            this.btnDodajRestauracje.UseVisualStyleBackColor = false;
            this.btnDodajRestauracje.Click += new System.EventHandler(this.btnDodajRestauracje_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(62, 100);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "Nazwa:";
            // 
            // txtNazwa
            // 
            this.txtNazwa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtNazwa.Location = new System.Drawing.Point(236, 100);
            this.txtNazwa.Name = "txtNazwa";
            this.txtNazwa.Size = new System.Drawing.Size(341, 26);
            this.txtNazwa.TabIndex = 4;
            // 
            // txtMiasto
            // 
            this.txtMiasto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtMiasto.Location = new System.Drawing.Point(236, 150);
            this.txtMiasto.Name = "txtMiasto";
            this.txtMiasto.Size = new System.Drawing.Size(341, 26);
            this.txtMiasto.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(62, 150);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "Miasto:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(62, 200);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(123, 20);
            this.label3.TabIndex = 7;
            this.label3.Text = "Województwo:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(62, 247);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(131, 20);
            this.label4.TabIndex = 8;
            this.label4.Text = "Typ restauracji:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.Location = new System.Drawing.Point(62, 296);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 20);
            this.label5.TabIndex = 9;
            this.label5.Text = "Dowóz:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.Location = new System.Drawing.Point(62, 344);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(153, 20);
            this.label6.TabIndex = 10;
            this.label6.Text = "Godzina otwarcia:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label7.Location = new System.Drawing.Point(62, 390);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(175, 20);
            this.label7.TabIndex = 11;
            this.label7.Text = "Godzina zamkniecia:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label8.Location = new System.Drawing.Point(62, 442);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(118, 20);
            this.label8.TabIndex = 12;
            this.label8.Text = "Ulica i numer:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label9.Location = new System.Drawing.Point(62, 487);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(103, 20);
            this.label9.TabIndex = 13;
            this.label9.Text = "Nr telefonu:";
            // 
            // cmbWojewodztwo
            // 
            this.cmbWojewodztwo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmbWojewodztwo.FormattingEnabled = true;
            this.cmbWojewodztwo.Items.AddRange(new object[] {
            "Dolnoslaskie",
            "Kujawsko-pomorskie",
            "Lubelskie",
            "Lubuskie",
            "Lodzkie",
            "Malopolskie",
            "Mazowieckie",
            "Opolskie",
            "Podkarpackie",
            "Podlaskie",
            "Pomorskie",
            "Slaskie",
            "Swietokrzyskie",
            "Warminsko-mazurskie",
            "Wielkopolskie",
            "Zachodniopomorskie"});
            this.cmbWojewodztwo.Location = new System.Drawing.Point(236, 200);
            this.cmbWojewodztwo.Name = "cmbWojewodztwo";
            this.cmbWojewodztwo.Size = new System.Drawing.Size(341, 28);
            this.cmbWojewodztwo.TabIndex = 14;
            // 
            // cmbTypRestauracji
            // 
            this.cmbTypRestauracji.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmbTypRestauracji.FormattingEnabled = true;
            this.cmbTypRestauracji.Items.AddRange(new object[] {
            "Fast food",
            "kuchnia wloska",
            "kuchnia azjatycka",
            "kuchnia polska",
            "kuchnia turecka",
            "kuchnia orientalna"});
            this.cmbTypRestauracji.Location = new System.Drawing.Point(236, 247);
            this.cmbTypRestauracji.Name = "cmbTypRestauracji";
            this.cmbTypRestauracji.Size = new System.Drawing.Size(341, 28);
            this.cmbTypRestauracji.TabIndex = 15;
            // 
            // cmbDowoz
            // 
            this.cmbDowoz.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmbDowoz.FormattingEnabled = true;
            this.cmbDowoz.Items.AddRange(new object[] {
            "Tak",
            "Nie"});
            this.cmbDowoz.Location = new System.Drawing.Point(236, 296);
            this.cmbDowoz.Name = "cmbDowoz";
            this.cmbDowoz.Size = new System.Drawing.Size(341, 28);
            this.cmbDowoz.TabIndex = 16;
            // 
            // mtxtGOtwarcie
            // 
            this.mtxtGOtwarcie.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.mtxtGOtwarcie.Location = new System.Drawing.Point(236, 344);
            this.mtxtGOtwarcie.Mask = "90:00";
            this.mtxtGOtwarcie.Name = "mtxtGOtwarcie";
            this.mtxtGOtwarcie.Size = new System.Drawing.Size(341, 26);
            this.mtxtGOtwarcie.TabIndex = 17;
            this.mtxtGOtwarcie.ValidatingType = typeof(System.DateTime);
            this.mtxtGOtwarcie.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.mtxtGOtwarcie_MaskInputRejected);
            // 
            // mtxtGZamkniecie
            // 
            this.mtxtGZamkniecie.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.mtxtGZamkniecie.Location = new System.Drawing.Point(236, 390);
            this.mtxtGZamkniecie.Mask = "90:00";
            this.mtxtGZamkniecie.Name = "mtxtGZamkniecie";
            this.mtxtGZamkniecie.Size = new System.Drawing.Size(341, 26);
            this.mtxtGZamkniecie.TabIndex = 18;
            this.mtxtGZamkniecie.ValidatingType = typeof(System.DateTime);
            // 
            // mtxtNrTelefonu
            // 
            this.mtxtNrTelefonu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.mtxtNrTelefonu.Location = new System.Drawing.Point(236, 484);
            this.mtxtNrTelefonu.Mask = "000-000-000";
            this.mtxtNrTelefonu.Name = "mtxtNrTelefonu";
            this.mtxtNrTelefonu.Size = new System.Drawing.Size(341, 26);
            this.mtxtNrTelefonu.TabIndex = 19;
            // 
            // txtUlica
            // 
            this.txtUlica.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtUlica.Location = new System.Drawing.Point(236, 440);
            this.txtUlica.Name = "txtUlica";
            this.txtUlica.Size = new System.Drawing.Size(341, 26);
            this.txtUlica.TabIndex = 20;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label10.Location = new System.Drawing.Point(184, 31);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(254, 25);
            this.label10.TabIndex = 21;
            this.label10.Text = "Dodawanie Restauracji";
            // 
            // OknoDodawania
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(654, 638);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txtUlica);
            this.Controls.Add(this.mtxtNrTelefonu);
            this.Controls.Add(this.mtxtGZamkniecie);
            this.Controls.Add(this.mtxtGOtwarcie);
            this.Controls.Add(this.cmbDowoz);
            this.Controls.Add(this.cmbTypRestauracji);
            this.Controls.Add(this.cmbWojewodztwo);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtMiasto);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtNazwa);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnDodajRestauracje);
            this.Controls.Add(this.btnZamknij);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "OknoDodawania";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "OknoDodawania";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnZamknij;
        private System.Windows.Forms.Button btnDodajRestauracje;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtNazwa;
        private System.Windows.Forms.TextBox txtMiasto;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cmbWojewodztwo;
        private System.Windows.Forms.ComboBox cmbTypRestauracji;
        private System.Windows.Forms.ComboBox cmbDowoz;
        private System.Windows.Forms.MaskedTextBox mtxtGOtwarcie;
        private System.Windows.Forms.MaskedTextBox mtxtGZamkniecie;
        private System.Windows.Forms.MaskedTextBox mtxtNrTelefonu;
        private System.Windows.Forms.TextBox txtUlica;
        private System.Windows.Forms.Label label10;
    }
}