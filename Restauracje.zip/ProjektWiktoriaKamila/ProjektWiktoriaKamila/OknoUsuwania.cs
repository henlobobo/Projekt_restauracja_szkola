﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjektWiktoriaKamila
{
    public partial class OknoUsuwania : Form
    {
        public OknoUsuwania()
        {
            InitializeComponent();
        }

        private void btnWroc_Click(object sender, EventArgs e)
        {

            Form form = new Form1();
            form.ShowDialog();
        }

        private void btnZamknij_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        public int DaneID(int id)
        {
            BazaDanych.polaczenie.Open();
            var cmd = BazaDanych.polaczenie.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT COUNT(*) FROM [Restauracje]  WHERE Id =" + id;
            int wynik = (int)(long)cmd.ExecuteScalar();
            cmd.ExecuteNonQuery();
            BazaDanych.polaczenie.Close();
            return wynik;
        }

        private void btnUsun_Click(object sender, EventArgs e)
        {
            int IdDoZaktualizowania = (int)numberId.Value;
            if (DaneID(IdDoZaktualizowania) == 0)
            {
                MessageBox.Show("Nie istnieje w bazie danych resturacje o Id=" + IdDoZaktualizowania);
            }
            else
            {
                DialogResult dialogResult = MessageBox.Show("Czy napewno chcesz usunac z bazy  danych resturacje o Id=" + IdDoZaktualizowania + "? ", "Czy usunac?", MessageBoxButtons.YesNoCancel);
                if (dialogResult == DialogResult.Yes)
                {
                    BazaDanych.polaczenie.Open();
                    var cmd = BazaDanych.polaczenie.CreateCommand();
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "DELETE FROM  [Restauracje] WHERE Id =" + IdDoZaktualizowania;

                    cmd.ExecuteNonQuery();
                    BazaDanych.polaczenie.Close();
                }

            }
        }

        private void OknoUsuwania_Load(object sender, EventArgs e)
        {

        }
    }
}
