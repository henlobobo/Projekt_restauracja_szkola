﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SQLite;


namespace ProjektWiktoriaKamila
{
    public static class BazaDanych
    {
        private static SQLiteConnection _polaczenie;

        public static SQLiteConnection polaczenie
        {
            get
            {
                if (_polaczenie == null)
                {
                    var sciezka = Path.GetFullPath($@"{Environment.CurrentDirectory}\..\..\Restauracje.sqlite");// zwaraca obecna sciezke do bazy danych 
                    _polaczenie = new SQLiteConnection($@"Data Source={sciezka};");
                    
                    StworzTabele();
                }
                return _polaczenie;
            }
        }

        private static void StworzTabele()
        {
            try
            {
                _polaczenie.Open();

                var sprawdzCzyIstniejeTabela = new SQLiteCommand("SELECT name FROM sqlite_master WHERE type='table' AND name='Restauracje';", _polaczenie);
                var czyIstnieje = sprawdzCzyIstniejeTabela.ExecuteScalar();

                if (czyIstnieje == null)
                {

                    var str = @"CREATE TABLE Restauracje (
    Id             INT          NOT NULL,
    Nazwa          VARCHAR (20) NULL,
    Miasto         VARCHAR (20) NULL,
    Ulica          VARCHAR (20) NULL,
    NrTelefonu     VARCHAR (12) NULL,
    Wojewodztwo    VARCHAR (30) NULL,
    [GOtwarcia]      VARCHAR (10) NULL,
    [GZamkniecia]    VARCHAR (10) NULL,
    [Dowoz]          VARCHAR (5)  NULL,
    [TypRestauracji] VARCHAR (25) NULL,
    PRIMARY KEY ([Id] ASC)
);";

                    var stworzTabele = new SQLiteCommand(str, _polaczenie);
                    stworzTabele.ExecuteNonQuery();
                }
            }
            finally
            {
                _polaczenie.Close();
            }

        }
    }
}
/*
System.Data.SqlClient.SqlException: „The database 'D:\PROJEKTWIKTORIAKAMILA\PROJEKTWIKTORIAKAMILA\RESTAURACJE.MDF' cannot be opened because it is version 904. This server supports version 852 and earlier. A downgrade path is not supported.
Could not open new database 'D:\PROJEKTWIKTORIAKAMILA\PROJEKTWIKTORIAKAMILA\RESTAURACJE.MDF'.CREATE DATABASE is aborted.
An attempt to attach an auto-named database for file D:\ProjektWiktoriaKamila\ProjektWiktoriaKamila\Restauracje.mdf failed.A database with the same name exists, or specified file cannot be opened, or it is located on UNC share.”

*/