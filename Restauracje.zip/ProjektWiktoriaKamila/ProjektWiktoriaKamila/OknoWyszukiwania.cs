﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SQLite;


namespace ProjektWiktoriaKamila
{
    public partial class OknoWyszukiwania : Form
    {
        public OknoWyszukiwania()
        {
            InitializeComponent();
        }

        private void OknoWyszukiwania_Load(object sender, EventArgs e)
        {

        }

        private void btnZamknij_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnWroc_Click(object sender, EventArgs e)
        {
            Form form = new Form1();
             form.ShowDialog();
            
        }
        public void WyswietlDane(string zapytanie)
        {
            BazaDanych.polaczenie.Open();
            var cmd = BazaDanych.polaczenie.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM  [Restauracje] " + zapytanie;
            //cmd.ExecuteNonQuery();
            SQLiteDataAdapter adapter = new SQLiteDataAdapter(cmd);
            DataTable tabela = new DataTable();
            adapter.Fill(tabela);

            dataGridView1.DataSource = tabela;
            BazaDanych.polaczenie.Close();
        }
        private void btnWszystkie_Click(object sender, EventArgs e)
        {
            WyswietlDane("");
        }
        public void UstawPuste()
        {
            txtNazwa.Text = "";
            txtMiasto.Text = "";
            cmbWojewodztwo.Text = "";
            cmbDowoz.Text = "";
            cmbTypRestauracji.Text = "";
            numberId.Value = 0;


        }
        private void button1_Click(object sender, EventArgs e)
        {
            string nazwa = txtNazwa.Text;
            string miasto = txtMiasto.Text;
            string wojewodztwo = cmbWojewodztwo.Text;
            string dowoz = cmbDowoz.Text;
            string typRestauracji = cmbTypRestauracji.Text;
            int id = (int)numberId.Value;
            string zapytanie = "WHERE ";
            if (nazwa != "")
            {
                zapytanie += "Nazwa = '" + nazwa + "' AND ";
            }
            if (miasto != "")
            {
                zapytanie += "Miasto = '" + miasto + "' AND ";
            }
            if (wojewodztwo != "")
            {
                zapytanie += "Wojewodztwo = '" + wojewodztwo + "' AND ";
            }
            if (dowoz != "")
            {
                zapytanie += "Dowoz = '" + dowoz + "' AND ";
            }
            if (typRestauracji != "")
            {
                zapytanie += "TypRestauracji = '" + typRestauracji + "' AND ";
            }
            if (id != 0)
            {
                zapytanie += "Id = " + id + "AND ";
            }
            if (zapytanie == "WHERE ")
            {
                zapytanie = " AND";
            }
            int pocztek = (int)(zapytanie.Length) - 4;

            zapytanie = zapytanie.Remove(pocztek, 3);

            WyswietlDane(zapytanie);
            //  MessageBox.Show(zapytanie);

        }
    }
}
