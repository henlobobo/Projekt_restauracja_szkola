﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjektWiktoriaKamila
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnZamknij_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnOWyszukania_Click(object sender, EventArgs e)
        {
            Form oknoWyszuknania = new OknoWyszukiwania();
            oknoWyszuknania.ShowDialog();
            
        }

        private void btnOUsuwania_Click(object sender, EventArgs e)
        {
            Form oknoUsuwania = new OknoUsuwania();
            oknoUsuwania.ShowDialog();
        }

        private void btnODodania_Click(object sender, EventArgs e)
        {
            Form oknoDodania = new OknoDodawania();
            oknoDodania.ShowDialog();

        }

        private void btnOModyfikacji_Click(object sender, EventArgs e)
        {
            Form oknoModyfikacjiDanych = new OknoModyfikacji();
            oknoModyfikacjiDanych.ShowDialog();
        }
    }
}
