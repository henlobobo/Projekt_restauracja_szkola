﻿
namespace ProjektWiktoriaKamila
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnOWyszukania = new System.Windows.Forms.Button();
            this.btnOUsuwania = new System.Windows.Forms.Button();
            this.btnODodania = new System.Windows.Forms.Button();
            this.btnOModyfikacji = new System.Windows.Forms.Button();
            this.btnZamknij = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(153, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(213, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Witamy w aplikacji ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(189, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(116, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Co chcesz zrobic?";
            // 
            // btnOWyszukania
            // 
            this.btnOWyszukania.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnOWyszukania.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnOWyszukania.Location = new System.Drawing.Point(12, 118);
            this.btnOWyszukania.Name = "btnOWyszukania";
            this.btnOWyszukania.Size = new System.Drawing.Size(192, 70);
            this.btnOWyszukania.TabIndex = 2;
            this.btnOWyszukania.Text = "Wyszukaj restaurację";
            this.btnOWyszukania.UseVisualStyleBackColor = false;
            this.btnOWyszukania.Click += new System.EventHandler(this.btnOWyszukania_Click);
            // 
            // btnOUsuwania
            // 
            this.btnOUsuwania.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnOUsuwania.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnOUsuwania.Location = new System.Drawing.Point(12, 202);
            this.btnOUsuwania.Name = "btnOUsuwania";
            this.btnOUsuwania.Size = new System.Drawing.Size(192, 70);
            this.btnOUsuwania.TabIndex = 3;
            this.btnOUsuwania.Text = "Usuń restaurację";
            this.btnOUsuwania.UseVisualStyleBackColor = false;
            this.btnOUsuwania.Click += new System.EventHandler(this.btnOUsuwania_Click);
            // 
            // btnODodania
            // 
            this.btnODodania.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnODodania.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnODodania.Location = new System.Drawing.Point(297, 118);
            this.btnODodania.Name = "btnODodania";
            this.btnODodania.Size = new System.Drawing.Size(192, 70);
            this.btnODodania.TabIndex = 4;
            this.btnODodania.Text = "Dodaj restaurację";
            this.btnODodania.UseVisualStyleBackColor = false;
            this.btnODodania.Click += new System.EventHandler(this.btnODodania_Click);
            // 
            // btnOModyfikacji
            // 
            this.btnOModyfikacji.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnOModyfikacji.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnOModyfikacji.Location = new System.Drawing.Point(297, 202);
            this.btnOModyfikacji.Name = "btnOModyfikacji";
            this.btnOModyfikacji.Size = new System.Drawing.Size(192, 70);
            this.btnOModyfikacji.TabIndex = 5;
            this.btnOModyfikacji.Text = "Modyfikuj dane restauracji";
            this.btnOModyfikacji.UseVisualStyleBackColor = false;
            this.btnOModyfikacji.Click += new System.EventHandler(this.btnOModyfikacji_Click);
            // 
            // btnZamknij
            // 
            this.btnZamknij.Location = new System.Drawing.Point(391, 292);
            this.btnZamknij.Name = "btnZamknij";
            this.btnZamknij.Size = new System.Drawing.Size(87, 23);
            this.btnZamknij.TabIndex = 6;
            this.btnZamknij.Text = "Zamknij";
            this.btnZamknij.UseVisualStyleBackColor = true;
            this.btnZamknij.Click += new System.EventHandler(this.btnZamknij_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(511, 336);
            this.Controls.Add(this.btnZamknij);
            this.Controls.Add(this.btnOModyfikacji);
            this.Controls.Add(this.btnODodania);
            this.Controls.Add(this.btnOUsuwania);
            this.Controls.Add(this.btnOWyszukania);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(527, 375);
            this.MinimumSize = new System.Drawing.Size(527, 375);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Aplikacja restauracja";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnOWyszukania;
        private System.Windows.Forms.Button btnOUsuwania;
        private System.Windows.Forms.Button btnODodania;
        private System.Windows.Forms.Button btnOModyfikacji;
        private System.Windows.Forms.Button btnZamknij;
    }
}

