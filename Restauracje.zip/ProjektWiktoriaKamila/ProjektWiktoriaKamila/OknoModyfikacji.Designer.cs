﻿
namespace ProjektWiktoriaKamila
{
    partial class OknoModyfikacji
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OknoModyfikacji));
            this.btnZamknij = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.txtUlica = new System.Windows.Forms.TextBox();
            this.mtxtNrTelefonu = new System.Windows.Forms.MaskedTextBox();
            this.mtxtGZamkniecie = new System.Windows.Forms.MaskedTextBox();
            this.mtxtGOtwarcie = new System.Windows.Forms.MaskedTextBox();
            this.cmbDowoz = new System.Windows.Forms.ComboBox();
            this.cmbTypRestauracji = new System.Windows.Forms.ComboBox();
            this.cmbWojewodztwo = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtMiasto = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtNazwa = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.numberId = new System.Windows.Forms.NumericUpDown();
            this.btnModyfikuj = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.lNazwa = new System.Windows.Forms.Label();
            this.IMiasto = new System.Windows.Forms.Label();
            this.lWojewodztwo = new System.Windows.Forms.Label();
            this.lTypRestauracji = new System.Windows.Forms.Label();
            this.lDowoz = new System.Windows.Forms.Label();
            this.lGOtwarcia = new System.Windows.Forms.Label();
            this.lGZamkniecia = new System.Windows.Forms.Label();
            this.lUlica = new System.Windows.Forms.Label();
            this.lNrTelefonu = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnWyswietRestauracje = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numberId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnZamknij
            // 
            this.btnZamknij.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnZamknij.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.btnZamknij.Location = new System.Drawing.Point(666, 601);
            this.btnZamknij.Margin = new System.Windows.Forms.Padding(4);
            this.btnZamknij.Name = "btnZamknij";
            this.btnZamknij.Size = new System.Drawing.Size(271, 59);
            this.btnZamknij.TabIndex = 2;
            this.btnZamknij.Text = "Zamknij";
            this.btnZamknij.UseVisualStyleBackColor = false;
            this.btnZamknij.Click += new System.EventHandler(this.btnZamknij_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label10.Location = new System.Drawing.Point(217, 28);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(354, 25);
            this.label10.TabIndex = 40;
            this.label10.Text = "Modyfikacja danych  Restauracji";
            // 
            // txtUlica
            // 
            this.txtUlica.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtUlica.Location = new System.Drawing.Point(666, 481);
            this.txtUlica.Name = "txtUlica";
            this.txtUlica.Size = new System.Drawing.Size(341, 26);
            this.txtUlica.TabIndex = 39;
            // 
            // mtxtNrTelefonu
            // 
            this.mtxtNrTelefonu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.mtxtNrTelefonu.Location = new System.Drawing.Point(666, 525);
            this.mtxtNrTelefonu.Mask = "000-000-000";
            this.mtxtNrTelefonu.Name = "mtxtNrTelefonu";
            this.mtxtNrTelefonu.Size = new System.Drawing.Size(341, 26);
            this.mtxtNrTelefonu.TabIndex = 38;
            // 
            // mtxtGZamkniecie
            // 
            this.mtxtGZamkniecie.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.mtxtGZamkniecie.Location = new System.Drawing.Point(666, 431);
            this.mtxtGZamkniecie.Mask = "90:00";
            this.mtxtGZamkniecie.Name = "mtxtGZamkniecie";
            this.mtxtGZamkniecie.Size = new System.Drawing.Size(341, 26);
            this.mtxtGZamkniecie.TabIndex = 37;
            this.mtxtGZamkniecie.ValidatingType = typeof(System.DateTime);
            // 
            // mtxtGOtwarcie
            // 
            this.mtxtGOtwarcie.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.mtxtGOtwarcie.Location = new System.Drawing.Point(666, 385);
            this.mtxtGOtwarcie.Mask = "90:00";
            this.mtxtGOtwarcie.Name = "mtxtGOtwarcie";
            this.mtxtGOtwarcie.Size = new System.Drawing.Size(341, 26);
            this.mtxtGOtwarcie.TabIndex = 36;
            this.mtxtGOtwarcie.ValidatingType = typeof(System.DateTime);
            // 
            // cmbDowoz
            // 
            this.cmbDowoz.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmbDowoz.FormattingEnabled = true;
            this.cmbDowoz.Items.AddRange(new object[] {
            "Tak",
            "Nie"});
            this.cmbDowoz.Location = new System.Drawing.Point(666, 337);
            this.cmbDowoz.Name = "cmbDowoz";
            this.cmbDowoz.Size = new System.Drawing.Size(341, 28);
            this.cmbDowoz.TabIndex = 35;
            // 
            // cmbTypRestauracji
            // 
            this.cmbTypRestauracji.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmbTypRestauracji.FormattingEnabled = true;
            this.cmbTypRestauracji.Items.AddRange(new object[] {
            "Fast food",
            "kuchnia wloska",
            "kuchnia azjatycka",
            "kuchnia polska",
            "kuchnia turecka",
            "kuchnia orientalna"});
            this.cmbTypRestauracji.Location = new System.Drawing.Point(666, 288);
            this.cmbTypRestauracji.Name = "cmbTypRestauracji";
            this.cmbTypRestauracji.Size = new System.Drawing.Size(341, 28);
            this.cmbTypRestauracji.TabIndex = 34;
            // 
            // cmbWojewodztwo
            // 
            this.cmbWojewodztwo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmbWojewodztwo.FormattingEnabled = true;
            this.cmbWojewodztwo.Items.AddRange(new object[] {
            "Dolnoslaskie",
            "Kujawsko-pomorskie",
            "Lubelskie",
            "Lubuskie",
            "Lodzkie",
            "Malopolskie",
            "Mazowieckie",
            "Opolskie",
            "Podkarpackie",
            "Podlaskie",
            "Pomorskie",
            "Slaskie",
            "Swietokrzyskie",
            "Warminsko-mazurskie",
            "Wielkopolskie",
            "Zachodniopomorskie"});
            this.cmbWojewodztwo.Location = new System.Drawing.Point(666, 241);
            this.cmbWojewodztwo.Name = "cmbWojewodztwo";
            this.cmbWojewodztwo.Size = new System.Drawing.Size(341, 28);
            this.cmbWojewodztwo.TabIndex = 33;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label9.Location = new System.Drawing.Point(32, 528);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(103, 20);
            this.label9.TabIndex = 32;
            this.label9.Text = "Nr telefonu:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label8.Location = new System.Drawing.Point(32, 483);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(118, 20);
            this.label8.TabIndex = 31;
            this.label8.Text = "Ulica i numer:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label7.Location = new System.Drawing.Point(32, 431);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(175, 20);
            this.label7.TabIndex = 30;
            this.label7.Text = "Godzina zamkniecia:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.Location = new System.Drawing.Point(32, 385);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(153, 20);
            this.label6.TabIndex = 29;
            this.label6.Text = "Godzina otwarcia:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.Location = new System.Drawing.Point(32, 337);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 20);
            this.label5.TabIndex = 28;
            this.label5.Text = "Dowóz:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(32, 288);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(131, 20);
            this.label4.TabIndex = 27;
            this.label4.Text = "Typ restauracji:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(32, 241);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(123, 20);
            this.label3.TabIndex = 26;
            this.label3.Text = "Województwo:";
            // 
            // txtMiasto
            // 
            this.txtMiasto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtMiasto.Location = new System.Drawing.Point(666, 191);
            this.txtMiasto.Name = "txtMiasto";
            this.txtMiasto.Size = new System.Drawing.Size(341, 26);
            this.txtMiasto.TabIndex = 25;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(32, 191);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 20);
            this.label2.TabIndex = 24;
            this.label2.Text = "Miasto:";
            // 
            // txtNazwa
            // 
            this.txtNazwa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtNazwa.Location = new System.Drawing.Point(666, 141);
            this.txtNazwa.Name = "txtNazwa";
            this.txtNazwa.Size = new System.Drawing.Size(341, 26);
            this.txtNazwa.TabIndex = 23;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(32, 141);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 20);
            this.label1.TabIndex = 22;
            this.label1.Text = "Nazwa:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label12.Location = new System.Drawing.Point(124, 85);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(401, 24);
            this.label12.TabIndex = 42;
            this.label12.Text = "Podaj Id restauracji, którą chcesz zmienić:";
            // 
            // numberId
            // 
            this.numberId.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.numberId.Location = new System.Drawing.Point(539, 78);
            this.numberId.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numberId.Name = "numberId";
            this.numberId.Size = new System.Drawing.Size(100, 31);
            this.numberId.TabIndex = 43;
            this.numberId.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // btnModyfikuj
            // 
            this.btnModyfikuj.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnModyfikuj.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.btnModyfikuj.Location = new System.Drawing.Point(117, 601);
            this.btnModyfikuj.Margin = new System.Windows.Forms.Padding(4);
            this.btnModyfikuj.Name = "btnModyfikuj";
            this.btnModyfikuj.Size = new System.Drawing.Size(271, 59);
            this.btnModyfikuj.TabIndex = 44;
            this.btnModyfikuj.Text = "Zaktualizuj";
            this.btnModyfikuj.UseVisualStyleBackColor = false;
            this.btnModyfikuj.Click += new System.EventHandler(this.btnModyfikuj_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(31, 568);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(283, 13);
            this.label13.TabIndex = 45;
            this.label13.Text = "*Zaktualizowane zostaną tylko pola, które zostały podane.";
            // 
            // lNazwa
            // 
            this.lNazwa.AutoSize = true;
            this.lNazwa.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lNazwa.Location = new System.Drawing.Point(278, 140);
            this.lNazwa.Name = "lNazwa";
            this.lNazwa.Size = new System.Drawing.Size(36, 25);
            this.lNazwa.TabIndex = 46;
            this.lNazwa.Text = "....";
            // 
            // IMiasto
            // 
            this.IMiasto.AutoSize = true;
            this.IMiasto.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.IMiasto.Location = new System.Drawing.Point(278, 191);
            this.IMiasto.Name = "IMiasto";
            this.IMiasto.Size = new System.Drawing.Size(36, 25);
            this.IMiasto.TabIndex = 47;
            this.IMiasto.Text = "....";
            // 
            // lWojewodztwo
            // 
            this.lWojewodztwo.AutoSize = true;
            this.lWojewodztwo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lWojewodztwo.Location = new System.Drawing.Point(278, 241);
            this.lWojewodztwo.Name = "lWojewodztwo";
            this.lWojewodztwo.Size = new System.Drawing.Size(36, 25);
            this.lWojewodztwo.TabIndex = 48;
            this.lWojewodztwo.Text = "....";
            // 
            // lTypRestauracji
            // 
            this.lTypRestauracji.AutoSize = true;
            this.lTypRestauracji.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lTypRestauracji.Location = new System.Drawing.Point(281, 288);
            this.lTypRestauracji.Name = "lTypRestauracji";
            this.lTypRestauracji.Size = new System.Drawing.Size(36, 25);
            this.lTypRestauracji.TabIndex = 49;
            this.lTypRestauracji.Text = "....";
            // 
            // lDowoz
            // 
            this.lDowoz.AutoSize = true;
            this.lDowoz.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lDowoz.Location = new System.Drawing.Point(281, 337);
            this.lDowoz.Name = "lDowoz";
            this.lDowoz.Size = new System.Drawing.Size(36, 25);
            this.lDowoz.TabIndex = 50;
            this.lDowoz.Text = "....";
            // 
            // lGOtwarcia
            // 
            this.lGOtwarcia.AutoSize = true;
            this.lGOtwarcia.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lGOtwarcia.Location = new System.Drawing.Point(278, 390);
            this.lGOtwarcia.Name = "lGOtwarcia";
            this.lGOtwarcia.Size = new System.Drawing.Size(36, 25);
            this.lGOtwarcia.TabIndex = 51;
            this.lGOtwarcia.Text = "....";
            // 
            // lGZamkniecia
            // 
            this.lGZamkniecia.AutoSize = true;
            this.lGZamkniecia.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lGZamkniecia.Location = new System.Drawing.Point(281, 438);
            this.lGZamkniecia.Name = "lGZamkniecia";
            this.lGZamkniecia.Size = new System.Drawing.Size(36, 25);
            this.lGZamkniecia.TabIndex = 52;
            this.lGZamkniecia.Text = "....";
            // 
            // lUlica
            // 
            this.lUlica.AutoSize = true;
            this.lUlica.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lUlica.Location = new System.Drawing.Point(281, 481);
            this.lUlica.Name = "lUlica";
            this.lUlica.Size = new System.Drawing.Size(36, 25);
            this.lUlica.TabIndex = 53;
            this.lUlica.Text = "....";
            // 
            // lNrTelefonu
            // 
            this.lNrTelefonu.AutoSize = true;
            this.lNrTelefonu.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lNrTelefonu.Location = new System.Drawing.Point(281, 528);
            this.lNrTelefonu.Name = "lNrTelefonu";
            this.lNrTelefonu.Size = new System.Drawing.Size(36, 25);
            this.lNrTelefonu.TabIndex = 54;
            this.lNrTelefonu.Text = "....";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Menu;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.Location = new System.Drawing.Point(12, 667);
            this.dataGridView1.Name = "dataGridView1";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.Size = new System.Drawing.Size(1065, 187);
            this.dataGridView1.TabIndex = 55;
            // 
            // btnWyswietRestauracje
            // 
            this.btnWyswietRestauracje.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnWyswietRestauracje.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnWyswietRestauracje.Location = new System.Drawing.Point(666, 78);
            this.btnWyswietRestauracje.Name = "btnWyswietRestauracje";
            this.btnWyswietRestauracje.Size = new System.Drawing.Size(398, 31);
            this.btnWyswietRestauracje.TabIndex = 56;
            this.btnWyswietRestauracje.Text = "Wyświetl restauracje o wybranym ID";
            this.btnWyswietRestauracje.UseVisualStyleBackColor = false;
            this.btnWyswietRestauracje.Click += new System.EventHandler(this.btnWyswietRestauracje_Click);
            // 
            // OknoModyfikacji
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(1107, 866);
            this.Controls.Add(this.btnWyswietRestauracje);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.lNrTelefonu);
            this.Controls.Add(this.lUlica);
            this.Controls.Add(this.lGZamkniecia);
            this.Controls.Add(this.lGOtwarcia);
            this.Controls.Add(this.lDowoz);
            this.Controls.Add(this.lTypRestauracji);
            this.Controls.Add(this.lWojewodztwo);
            this.Controls.Add(this.IMiasto);
            this.Controls.Add(this.lNazwa);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.btnModyfikuj);
            this.Controls.Add(this.numberId);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txtUlica);
            this.Controls.Add(this.mtxtNrTelefonu);
            this.Controls.Add(this.mtxtGZamkniecie);
            this.Controls.Add(this.mtxtGOtwarcie);
            this.Controls.Add(this.cmbDowoz);
            this.Controls.Add(this.cmbTypRestauracji);
            this.Controls.Add(this.cmbWojewodztwo);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtMiasto);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtNazwa);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnZamknij);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "OknoModyfikacji";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "OknoModyfikacji";
            this.Load += new System.EventHandler(this.NaZaloadowanie);
            ((System.ComponentModel.ISupportInitialize)(this.numberId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnZamknij;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtUlica;
        private System.Windows.Forms.MaskedTextBox mtxtNrTelefonu;
        private System.Windows.Forms.MaskedTextBox mtxtGZamkniecie;
        private System.Windows.Forms.MaskedTextBox mtxtGOtwarcie;
        private System.Windows.Forms.ComboBox cmbDowoz;
        private System.Windows.Forms.ComboBox cmbTypRestauracji;
        private System.Windows.Forms.ComboBox cmbWojewodztwo;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtMiasto;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtNazwa;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.NumericUpDown numberId;
        private System.Windows.Forms.Button btnModyfikuj;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lNazwa;
        private System.Windows.Forms.Label IMiasto;
        private System.Windows.Forms.Label lWojewodztwo;
        private System.Windows.Forms.Label lTypRestauracji;
        private System.Windows.Forms.Label lDowoz;
        private System.Windows.Forms.Label lGOtwarcia;
        private System.Windows.Forms.Label lGZamkniecia;
        private System.Windows.Forms.Label lUlica;
        private System.Windows.Forms.Label lNrTelefonu;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnWyswietRestauracje;
    }
}